<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        Schema::create('geojson_files', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->geometry('geometry', 'GeometryCollection', 4326);// SRID 4326 is commonly used for WGS84
            $table->json('geojson')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('geojson_files');
    }
};
