<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/save-geojson', [App\Http\Controllers\GeoJsonController::class, 'saveGeoJson']);

Route::post('/delete-geojson', [App\Http\Controllers\GeoJsonController::class, 'deleteGeoJsonRecord']);

Route::get('/list-geojson', [App\Http\Controllers\GeoJsonController::class, 'getGeoJson']);

Route::get('/get-geojson/{id}', [App\Http\Controllers\GeoJsonController::class, 'getGeoJsonById']);