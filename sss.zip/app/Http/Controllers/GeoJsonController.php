<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\GeojsonFile;
use Illuminate\Support\Facades\Log;
use Clickbar\Magellan\Data\Geometries\Geometry;
use Clickbar\Magellan\Data\Geometries\GeometryCollection;
use Clickbar\Magellan\Data\Geometries\Point;
use Clickbar\Magellan\Data\Geometries\LineString;
use Clickbar\Magellan\Data\Geometries\Polygon;
use Clickbar\Magellan\Data\Geometries\MultiPolygon;

class GeoJsonController extends Controller
{
    public function saveGeoJson(Request $request)
{
    $request->validate([
        'data' => 'required|array',
    ]);

    $layers = $request->input('data');
    $geometries = [];
    $properties = [];
    $savedCount = 0;

    foreach ($layers as $key => $layer) {
        try {
            if (!isset($layer['type']) || $layer['type'] !== 'FeatureCollection') {
                Log::warning("Skipping non-FeatureCollection layer at index {$key}");
                continue;
            }

            foreach ($layer['features'] as $feature) {
                if (!isset($feature['geometry'])) {
                    Log::warning("Skipping feature with no geometry at index {$key}");
                    continue;
                }

                // Convert the geometry to a Magellan object
                $geometry = $this->convertGeoJsonToGeometry($feature['geometry']);
                if ($geometry) {
                    $geometries[] = $geometry;
                    $properties[] = $feature['properties'] ?? []; // Save properties or empty array
                    $savedCount++;
                }
            }
        } catch (\Exception $e) {
            Log::error("Error processing layer {$key}: " . $e->getMessage());
            continue;
        }
    }

    if (empty($geometries)) {
        return response()->json([
            'message' => 'No valid geometries found in the GeoJSON data.',
        ], 400);
    }

    try {
        $geometryCollection = GeometryCollection::make($geometries);

        if ($request->input('id')) {
            $test = GeojsonFile::find($request->input('id'));
            
            if (!$test) {
                return response()->json(['message' => 'GeoData not found'], 404);
            }

            $test->update([
                'geojson' => $request->input('data'), // Save properties as JSON
            ]);
        } else {
            $test = GeojsonFile::create([
                'name' => $request->input('name'),
                'geometry' => $geometryCollection,
                'geojson' => $request->input('data'), // Save properties as JSON
            ]);
        }



        return response()->json([
            'message' => 'Successfully saved GeometryCollection',
            'data' => $test->id,
        ], 201);
    } catch (\Exception $e) {
        return response()->json([
            'message' => 'Error saving GeoJSON data',
            'error' => $e->getMessage(),
        ], 500);
    }
}

    protected function convertGeoJsonToGeometry(array $geoJson): ?Geometry
    {
        if (!isset($geoJson['type'])) {
            return null;
        }

        // Remove unsupported properties like 'bbox'
        if (isset($geoJson['bbox'])) {
            unset($geoJson['bbox']);
        }

        switch ($geoJson['type']) {
            case 'Point':
                return Point::make($geoJson['coordinates'][0], $geoJson['coordinates'][1]);
                
            case 'LineString':
                $points = array_map(
                    fn($coord) => Point::make($coord[0], $coord[1]),
                    $geoJson['coordinates']
                );
                return LineString::make($points);
                
            case 'Polygon':
                $linestrings = [];
                foreach ($geoJson['coordinates'] as $ring) {
                    $points = array_map(
                        fn($coord) => Point::make($coord[0], $coord[1]),
                        $ring
                    );
                    $linestrings[] = LineString::make($points);
                }
                return Polygon::make($linestrings);
                
            case 'MultiPolygon':
                $polygons = [];
                foreach ($geoJson['coordinates'] as $polygonCoords) {
                    $linestrings = [];
                    foreach ($polygonCoords as $ring) {
                        $points = array_map(
                            fn($coord) => Point::make($coord[0], $coord[1]),
                            $ring
                        );
                        $linestrings[] = LineString::make($points);
                    }
                    $polygons[] = Polygon::make($linestrings);
                }
                return MultiPolygon::make($polygons);
                
            default:
                Log::warning("Unsupported geometry type: {$geoJson['type']}");
                return null;
        }
    }

    public function getGeoJsonById(string $id)
    {
        $geojsonFile = GeojsonFile::find($id);

        if (!$geojsonFile) {
            return response()->json(['message' => 'GeoData not found'], 404);
        }

        return response()->json([
            'message' => 'GeoData retrieved successfully',
            'data' => [
                'id' => $geojsonFile->id,
                'name' => $geojsonFile->name,
                'geometry' => $geojsonFile->geometry
            ],
        ]);
    }

    protected function geometryToFeatureCollection(Geometry $geometry, array $properties): array
{
    $features = [];
    
    if ($geometry instanceof GeometryCollection) {
        foreach ($geometry->getGeometries() as $index => $geom) {
            $features[] = [
                'type' => 'Feature',
                'geometry' => $geom->jsonSerialize(),
                'properties' => $properties[$index] ?? [], // Match properties to geometry
            ];
        }
    } else {
        $features[] = [
            'type' => 'Feature',
            'geometry' => $geometry->jsonSerialize(),
            'properties' => $properties[0] ?? [], // Use the first property if available
        ];
    }
    
    return [
        'type' => 'FeatureCollection',
        'features' => $features,
    ];
}

    public function getGeoJson()
    {
     return GeojsonFile::paginate(1000);
    }

    public function deleteGeoJsonRecord(Request $request)
    {
        
        GeojsonFile::where('id', $request->input('id'))->delete();

        return ['message' => 'GeoData deleted successfully'];
        
    }
}